package com.teachmeskills.temp;

import com.teachmeskills.temp.Service.MainHandler;
import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

/**
 * @author zafarzhon
 * @link https://github.com/zafarzhon
 */
public class Main {
    public static void main(String[] args) {
        ApplicationContext context = new AnnotationConfigApplicationContext("com.teachmeskills");
        MainHandler mainHandler = context.getBean(MainHandler.class);
        mainHandler.run();
    }
}
