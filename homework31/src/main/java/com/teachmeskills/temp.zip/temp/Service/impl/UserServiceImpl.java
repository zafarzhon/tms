package com.teachmeskills.temp.Service.impl;

import com.teachmeskills.temp.Entity.User;
import com.teachmeskills.temp.Service.DataService;
import com.teachmeskills.temp.Service.NotificationService;
import com.teachmeskills.temp.Service.UserService;
import com.teachmeskills.temp.Service.ValidationService;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.List;

/**
 * @author zafarzhon
 * @link https://github.com/zafarzhon
 */
@Service
@RequiredArgsConstructor
public class UserServiceImpl implements UserService {
    private final List<ValidationService> validationServices;
    private final DataService dataService;
    private final List<NotificationService> notificationServices;

    @Override
    public void save(User user) {
        validationServices.forEach(validationService -> validationService.validate(user));
        dataService.save(user);
        notificationServices.forEach(notificationService -> notificationService.sendNotification(user));
    }
}
