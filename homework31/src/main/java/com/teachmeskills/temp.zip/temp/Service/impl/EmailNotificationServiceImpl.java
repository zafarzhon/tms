package com.teachmeskills.temp.Service.impl;

import com.teachmeskills.temp.Entity.User;
import com.teachmeskills.temp.Service.NotificationService;
import org.springframework.stereotype.Service;

/**
 * @author zafarzhon
 * @link https://github.com/zafarzhon
 */
@Service
public class EmailNotificationServiceImpl implements NotificationService {
    @Override
    public void sendNotification(User user) {
        System.out.println("send email notification: "+user.getName());
    }
}
