package com.teachmeskills.temp.Service;

import com.teachmeskills.temp.Entity.User;

/**
 * @author zafarzhon
 * @link https://github.com/zafarzhon
 */
public interface UserService {
    void save(User user);
}
