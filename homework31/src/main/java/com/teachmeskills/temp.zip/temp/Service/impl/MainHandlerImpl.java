package com.teachmeskills.temp.Service.impl;

import com.teachmeskills.temp.Entity.User;
import com.teachmeskills.temp.Service.MainHandler;
import com.teachmeskills.temp.Service.UserService;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.Scanner;

/**
 * @author zafarzhon
 * @link https://github.com/zafarzhon
 */
@Service
@RequiredArgsConstructor
public class MainHandlerImpl implements MainHandler {
    private final UserService userService;
    @Override
    public void run() {
        Scanner scanner = new Scanner(System.in);
        String name = scanner.next();
        String pass = scanner.next();

        User user = new User(name,pass);
        userService.save(user);
    }
}
