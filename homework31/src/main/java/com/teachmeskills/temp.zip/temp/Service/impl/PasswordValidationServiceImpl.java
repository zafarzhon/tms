package com.teachmeskills.temp.Service.impl;

import com.teachmeskills.temp.Entity.User;
import com.teachmeskills.temp.Service.ValidationService;
import org.springframework.stereotype.Service;

/**
 * @author zafarzhon
 * @link https://github.com/zafarzhon
 */
@Service
public class PasswordValidationServiceImpl implements ValidationService {
    @Override
    public void validate(User user) {
        if(user== null || user.getPassword().length()<4 || user.getPassword().length()>12){
            throw new RuntimeException("Invalid password");
        }
    }
}
