package com.teachmeskills.temp.Entity;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.Setter;

/**
 * @author zafarzhon
 * @link https://github.com/zafarzhon
 */
@Getter @Setter
@AllArgsConstructor
public class User {
    private String name;
    private String password;
}
