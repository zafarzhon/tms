package com.teachmeskills.temp.Service;

/**
 * @author zafarzhon
 * @link https://github.com/zafarzhon
 */
public interface MainHandler {
    public void run();
}
