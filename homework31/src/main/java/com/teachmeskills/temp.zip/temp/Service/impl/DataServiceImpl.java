package com.teachmeskills.temp.Service.impl;

import com.teachmeskills.temp.Entity.User;
import com.teachmeskills.temp.Service.DataService;
import org.springframework.stereotype.Service;

/**
 * @author zafarzhon
 * @link https://github.com/zafarzhon
 */
@Service
public class DataServiceImpl implements DataService {
    @Override
    public void save(User user) {
        System.out.println("save user: " + user.getName());
    }
}
