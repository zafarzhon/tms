package com.teachmeskills.temp.Service.impl;

import com.teachmeskills.temp.Entity.User;
import com.teachmeskills.temp.Service.ValidationService;
import org.springframework.stereotype.Service;

/**
 * @author zafarzhon
 * @link https://github.com/zafarzhon
 */
@Service
public class NameValidationServiceImpl implements ValidationService {
    @Override
    public void validate(User user) {
        if (user == null || user.getName().length() < 4 || user.getName().length() > 50) {
            throw new RuntimeException("Name length should be between 4 and 50 characters");
        }
    }
}
